/**
 * Created by jiachenpan on 16/11/18.
 */

// export function isvalidUsername (str) {
//   const valid_map = ['admin', 'editor'];
//   return valid_map.indexOf(str.trim()) >= 0;
// }
// // 将字节速率转化成其他大小
// export function changeRate (val) {
//
// }
// 将字节转化成其他单位大小
export function changeSize (val) {
  if (val < 0) {
    return -1;
  }
  let symbols = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  let exp = Math.floor(Math.log(val) / Math.log(2));
  if (exp < 1) {
    exp = 0;
  }
  let i = Math.floor(exp / 10);
  val = val / Math.pow(2, 10 * i);

  if (val.toString().length > val.toFixed(2).toString().length) {
    val = val.toFixed(2);
  }
  return val + ' ' + symbols[i];
}
// 密码的显示隐藏
export function showPassword (type, name, that) {
  if (type === 'password') {
    that[name] = 'text';
  } else if (type === 'text') {
    that[name] = 'password';
  }
}
// 返回信息提示
export function notify (that, msg, type) {
  that.$notify({
    message: msg,
    type: type,
    duration: 2000
  });
}

// 是否继续操作
export function deleteAlert (that, resover, row, msg) {
  that.$confirm(msg, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
    callback: action => {
      if (action === 'confirm') {
        resover(row);
      } else {
        that.$notify({
          message: '已取消',
          type: 'info',
          duration: 2000
        });
      }
    }
  });
}

export function isipcheck (str) {
  const ipreg = /^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$/gi;
  return ipreg.test(str);
}
/* 合法uri */
export function validateURL (textval) {
  const urlregex = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/;
  return urlregex.test(textval);
}

/* 小写字母 */
export function validateLowerCase (str) {
  const reg = /^[a-z]+$/;
  return reg.test(str);
}

/* 大写字母 */
export function validateUpperCase (str) {
  const reg = /^[A-Z]+$/;
  return reg.test(str);
}

/* 大小写字母 */
export function validatAlphabets (str) {
  const reg = /^[A-Za-z]+$/;
  return reg.test(str);
}
