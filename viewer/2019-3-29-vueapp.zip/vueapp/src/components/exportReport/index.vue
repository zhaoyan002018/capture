<template>
  <div>
    <div class="app-container">
      <div class="interfaceSet">手动导出报表</div>
      <div class="filter-container borders" style="float:left">
        <el-button :loading="downloadLoading" class="green outline" type="text" icon="el-icon-refresh" native-type="reset" @click="getList()"> 刷新 </el-button>
      </div>
      <div>
        <span @click="showExport()">查看</span>
      </div>
      <template>
       <article style="    display: inline-block;
    width: 150px;
    height: 200px;
    position: relative;
    border: 1px solid #ccc;
    left: 30px;
    top: 30px;
    border-radius: 10px;">
         <div class="pdf_logo"></div>
         <div class="top_right_triangle"></div>
       </article>
      </template>
      <!--<el-dialog :visible.sync="dialogFormVisible" title="编辑绑定用户信息" width="400px" @close="resetTemp()">-->
        <!--<div class="form">-->
          <!--<el-form ref="dataForm" :model="temp" status-icon auto-complete="on" label-position="left" label-width="110px" style="margin-left:28px;" size="mini">-->
            <!--<el-form-item label="用户名">-->
              <!--<span>{{temp.name}}</span>-->
            <!--</el-form-item>-->
            <!--<el-form-item label="绑定IP">-->
              <!--<el-input v-model="temp.bundIp"></el-input>-->
            <!--</el-form-item>-->
          <!--</el-form>-->
        <!--</div>-->
        <!--<div slot="footer" class="dialog-footer">-->
          <!--<el-button size="small" icon="el-icon-refresh" class="outline" type="info" @click="dialogFormVisible = false" >取消</el-button>-->
          <!--<el-button size="small" icon="el-icon-circle-check-outline" class="outline" type="primary" @click="dialogStatus==='create'?createData():updateData()">确定</el-button>-->
        <!--</div>-->
      <!--</el-dialog>-->
      <!--loading overlay -->
      <moloch-loading
        v-if="listLoading && !error">
      </moloch-loading> <!-- /loading overlay -->
    </div>
  </div>
</template>

<script>
// import { fetcharticle, updatearticle, deleteacticle, createArticle, editUpdatearticle } from '@/api/article';
import { deleteAlert } from '@/api/validate';
// import MolochPaging from '@/components/utils/Pagination';
import MolochLoading from '@/components/utils/Loading';

export default {
  components: {
    MolochLoading
    // MolochPaging
  },
  data () {
    return {
      activeName2: 'first',
      downloadLoading: false,
      mySearch: '',
      list: null,
      interfaceList: null,
      listLoading: false,
      error: '',
      total: 0,
      listQuery: {
        length: parseInt(this.$route.query.length) || 500,
        start: 0,
        filter: null
      },
      temp: {},
      dialogFormVisible: false,
      dialogStatus: '',
      checked: true
    };
  },
  created () {
  },
  methods: {
    showExport () {

    },
    Confirm (row) {
      let that = this;
      deleteAlert(that, this.handleDelete, row, '此操作将永久删除该用户信息，是否继续');
    },
    resetTemp () {
      this.temp = {
        interfaces: []
      };
    }
  }
};
</script>
<style scoped>
  .pdf_logo{
    position: absolute;
    width: 50px;
    height: 50px;
    top: 119px;
    left: -23px;
    border-radius: 7px;
    background: url("../../assets/pdf.png");
    background-size: 100% 100%;
  }
  .action span{
    margin-left:20px;
  }
  .interfaceSet{
    width: 150px;
    height: 35px;
    line-height:35px;
    text-align: center;
    border:1px solid #f0f0f0;
    border-bottom:#fff;
    font-size:14px;
    position:relative;
    top:50px;
    z-index: 3;
    background: #ffffff;
  }
  .borders{
    position: relative;
    top: 49px;
    z-index: 2;
    border:1px solid #f0f0f0;
    padding-left:20px;
    width: 100%;
    border-bottom: transparent;
  }
  .links-table{
    position: relative;
    top: 49px;
  }
</style>
