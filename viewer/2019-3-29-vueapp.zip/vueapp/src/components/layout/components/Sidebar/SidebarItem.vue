<template>
  <div v-if="!item.hidden">
    <!--{{ item.name }}-->
    <!--{{ item.name }} 路由的路径内容都获取到了-->
    <template v-if="hasOneShowingChild(item.children,item) && (!onlyOneChild.children||onlyOneChild.noShowingChildren)&& !item.alwaysShow">
      <router-link :to="{name: onlyOneChild.name, query: menu[onlyOneChild.name].query, params: {nav: true}}" :key="onlyOneChild.name">
        <el-menu-item :index="onlyOneChild.name" :class="{'submenu-title-noDropdown':!isNest}">
           <span v-if="menu[onlyOneChild.name].hotkey">
              <p v-for="(text, index) in menu[onlyOneChild.name].hotkey" :key="text" :class="{'holding-shift':shiftKeyHold && index === menu[onlyOneChild.name].hotkey.length-1,'shortcut-letter': index === menu[onlyOneChild.name].hotkey.length-1}">
                {{text}}
              </p>
           </span>
          <p class="link_title">
            <item :icon="onlyOneChild.name" :title="onlyOneChild.meta.title"></item>
          </p>
        </el-menu-item>
      </router-link>
    </template>
    <el-submenu v-else :index="item.name" ref="submenu">
      <template slot="title" class="hidden_svg">
        <item :icon="item.name" :title="item.meta.title"></item>
      </template>
      <template v-for="child in item.children">
        <sidebar-item
        v-if="child.children&&child.children.length>0"
        :is-nest="true"
        :item="child"
        :key="child.path"
        :base-path="resolvePath(child.path)"
        class="nest-menu" />
        <router-link v-else :to="{name: child.name, query: menu[child.name].query, prams: {nav: true} }" :key="child.name">
          <el-menu-item :index="child.name">
            <!--<span v-if="menu[onlyOneChild.name].hotkey">-->
              <!--<p v-for="(text, index) in menu[onlyOneChild.name].hotkey" :key="text" :class="{'holding-shift':shiftKeyHold && index === menu[onlyOneChild.name].hotkey.length-1,'shortcut-letter': index === menu[onlyOneChild.name].hotkey.length-1}">-->
                <!--{{text}}-->
              <!--</p>-->
           <!--</span>-->
            <p class="link_title" style="margin-left: 10px;">
              <item :icon="child.meta.link" :title="child.meta.title"></item>
            </p>
          </el-menu-item>
        </router-link>
      </template>
    </el-submenu>
  </div>
</template>

<script>
import qs from 'qs';
import Item from './Item';
export default {
  name: 'SidebarItem',
  components: { Item },
  props: {
    // route object
    item: {
      type: Object,
      required: true
    },
    isNest: {
      type: Boolean,
      default: false
    },
    basePath: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      onlyOneChild: null
    };
  },
  computed: {
    menu: function () {
      let menu = {
        sessions: { title: this.$t('navbar.sessions'), link: 'sessions' },
        spiview: { title: this.$t('navbar.spiview'), link: 'spiview' },
        spigraph: { title: this.$t('navbar.spigraph'), link: 'spigraph' },
        spigraphindex: { title: this.$t('navbar.spigraph'), link: 'spigraphindex' },
        worldmap: { title: '世界地图', link: 'worldmap' },
        chinamap: { title: '国内地图', link: 'chinamap' },
        connections: { title: this.$t('navbar.connections'), link: 'connections' },
        files: { title: this.$t('navbar.files'), link: 'files', permission: 'hideFiles', reverse: true },
        stats: { title: this.$t('navbar.stats'), link: 'stats', permission: 'hideStats', reverse: true },
        upload: { title: this.$t('navbar.upload'), link: 'upload', permission: 'canUpload' },
        network: { title: '网络配置', link: 'network' },
        interfaces: { title: '接口配置', link: 'interfaces' },
        routing: { title: '路由配置', link: 'routing' },
        linking: { title: '链路配置', link: 'linking' },
        system: { title: '系统配置', link: 'system' },
        time: { title: '时间配置', link: 'time' },
        platRunState: { title: '平台运行状况', link: 'runState' },
        eventconfigure: { title: '事件配置', link: 'eventconfigure' },
        strategy: {title: '策略配置', link: 'strategy'},
        eventmarage: {title: '攻击事件', link: 'eventmarage'},
        report: {title: 'dps报表', link: 'report'},
        userIp: {title: '用户绑定', link: 'userIp'},
        ruleBase: {title: '规则库', link: 'ruleBase'},
        exportReport: {title: '导出报表', link: 'exportReport'}
      };
      if (!this.$constants.DPS_MULTIVIEWER) {
        menu.hunt = { title: this.$t('navbar.hunt'), link: 'hunt', permission: 'packetSearch' };
      }

      if (!this.$constants.DPS_DEMO_MODE) {
        menu.history = { title: this.$t('navbar.history'), link: 'history' };
        menu.settings = { title: this.$t('navbar.settings'), link: 'settings' };
        menu.users = { title: this.$t('navbar.users'), link: 'users', permission: 'createEnabled' };
      }

      // preserve url query parameters
      for (let m in menu) {
        let item = menu[m];
        item.href = `${item.link}?${qs.stringify(this.$route.query)}`;
        // make sure the stored expression is part of the query
        item.query = {
          ...this.$route.query,
          expression: this.$store.state.expression
        };
        // update the start/stop time if they have not been updated
        if ((this.$store.state.time.startTime !== this.$route.query.startTime ||
          this.$store.state.time.stopTime !== this.$route.query.stopTime) &&
          this.$store.state.timeRange === '0') {
          item.query.startTime = this.$store.state.time.startTime;
          item.query.stopTime = this.$store.state.time.stopTime;
          item.query.date = undefined;
        }
        // determine if user can view menu item
        // this can't be done with the has-permission directive because
        // a sibling of this component might update the user (Users.vue)
        if (this.user) {
          item.hasPermission = !item.permission ||
            (this.user.hasOwnProperty(item.permission) && this.user[item.permission] && !item.reverse) ||
            (!this.user.hasOwnProperty(item.permission) || (!this.user[item.permission] && item.reverse));
        }
      }
      // 检查该函数执行下来的menu和vuex中存储的menu的值是否相同，如果相同则直接跳过下面的commit操作，
      // 如果不相同，进入commit操作
      const menuBool = this.checkMenu(menu, this.$store.state.menu);
      // 把menu的结果使用vuex保存起来
      if (menuBool === true) {
        this.$store.commit('setMenu', menu);
      }
      return menu;
    },
    user: function () {
      return this.$store.state.user;
    }
  },
  methods: {
    hasOneShowingChild (children, parent) {
      const showingChildren = children.filter(item => {
        if (item.hidden) {
          return false;
        } else {
          // Temp set(will be used if only has one showing child)
          this.onlyOneChild = item;
          return true;
        }
      });

      // When there is only one child router, the child router is displayed by default
      if (showingChildren.length === 1) {
        return true;
      }

      // Show parent if there are no child router to display
      if (showingChildren.length === 0) {
        this.onlyOneChild = { ...parent, path: '', noShowingChildren: true };
        return true;
      }

      return false;
    },
    checkMenu (obj, vuexObj) {
      if (vuexObj === undefined) {
        return true;
      }
      for (let i in obj) {
        if (typeof (obj[i]) === 'object') {
          this.checkMenu(obj[i], vuexObj[i]);
        } else {
          if (obj[i] !== vuexObj[i]) {
            return true;
          }
        }
      }
    }
  }
};
</script>
