<template>

  <div class="moloch-info container">

  <div class="center-area">

    <img src="watching.gif" />

    <div class="well well-lg">
      <h1>浏览器不兼容</h1>
      <h4>请更新您的浏览器!</h4>
    </div>

    <br/>

    <div class="mb-2 mt-2">
      <a href="https://github.com/aol/moloch/wiki/FAQ#what-browsers-are-supported"
        class="no-decoration">
        dps兼容的的浏览器
      </a>
    </div>

  </div>

</div>

</template>

<script>
export default {
  name: 'MolochUpgradeBrowser'
};
</script>
