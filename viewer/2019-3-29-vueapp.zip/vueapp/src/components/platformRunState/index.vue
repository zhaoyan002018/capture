<template>
  <div id="platRunState" class="app-container" style="height: 100%;">
    <div class="state">
      <div>
        <el-button class="refresh outline"
                   type="text" icon="el-icon-refresh" native-type="reset" @click="getList()"> 刷新 </el-button>
      </div>
      <div v-if="!listLoading">
        <el-row class="state_row">
          <el-col :span="7" class="state_col_4">
            <div style="width: 100%; height: 100%;position: relative;text-align: center;">
              <div class="state_title"><span>CPU</span></div>
              <div>
                <el-progress type="circle" color="rgb(19, 206, 102)" :width="200" :percentage="20" style="margin: 0 auto;"></el-progress>
                <div class="runStateMore">
                </div>
              </div>
            </div>
          </el-col>
          <el-col :span="17" style="height: 100%;">
            <!--echarts-->
            <!--<div id="CPU" style="background: #000;width: 100%;height: 100%;"></div>-->
            <ve-line style="height: 100%;" :data="cpuData" :settings="secondSettings" :extend="cpuExtend"></ve-line>
          </el-col>
        </el-row>
        <el-row class="state_row">
          <el-col :span="7"  class="state_col_4">
            <div style="width: 100%; height: 100%;position: relative;text-align: center;">
              <div class="state_title"><span>内存</span></div>
              <div>
                <el-progress type="circle" color="#f00" :width="200" :percentage="100" style="margin: 0 auto;"></el-progress>
                <div class="runStateMore">
                  <span>已使用:</span><span>{{memory.used}}</span><br />
                  <span>总容量:</span><span>{{memory.total}}</span><br />
                </div>
              </div>
            </div>
          </el-col>
          <el-col :span="17" style="height: 100%;">
            <!--echarts-->
            <!--<div id="CPU" style="background: #000;width: 100%;height: 100%;"></div>-->
            <ve-line style="height: 100%;" :data="memoryData" :settings="secondSettings" :extend="memoryExtend"></ve-line>
          </el-col>
        </el-row>
        <el-row class="state_row">
          <el-col :span="7" class="state_col_4">
            <div style="width: 100%; height: 100%;position: relative;text-align: center;">
              <div class="state_title"><span>磁盘</span></div>
              <div>
                <el-progress type="circle" color="yellow" :width="200" :percentage="70" style="margin: 0 auto;"></el-progress>
                <div class="runStateMore">
                  <span>使用中:</span><span>{{dist.used}}</span><br />
                  <span>总容量:</span><span>{{dist.total}}</span><br />
                </div>
              </div>
            </div>
          </el-col>
          <el-col :span="17" style="height: 100%;">
            <ve-line style="height: 100%;" :data="distData" :extend="distExtend"></ve-line>
          </el-col>
        </el-row>
      </div>
    </div>
    <moloch-loading
      v-if="listLoading && !error">
    </moloch-loading> <!-- /loading overlay -->
 </div>
</template>

<script>
import { getarticle } from '@/api/article';
import MolochLoading from '@/components/utils/Loading';
import { changeSize } from '@/api/validate';

export default {
  name: 'platRunState',
  components: {
    MolochLoading
  },
  data: function () {
    this.secondSettings = {
      area: true
    };
    this.memoryExtend = {
      xAxis: {
        type: 'time',
        formatter: function (value) {
          return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
        }
      },
      yAxis: {
        position: 'left',
        name: '内存使用率(%)',
        min: 0,
        max: 100,
        interval: 20
      }
    };
    this.distExtend = {
      yAxis: {
        position: 'left',
        name: 'KB/S'
      }
    };
    this.cpuExtend = {
      yAxis: {
        position: 'left',
        name: '利用率(%)',
        min: 0,
        max: 100,
        interval: 20
      }
    };
    return {
      cpu: {},
      cpuData: {
        columns: ['time', 'ratio'],
        rows: []
      },
      memory: {},
      memoryData: {
        columns: ['time', 'ratio'],
        rows: []
      },
      dist: {},
      distData: {
        columns: ['time', 'read', 'write'],
        rows: []
      },
      listLoading: true,
      error: '',
      recordsTotal: undefined,
      recordsFiltered: undefined,
      data: null,
      percentage: {}
    };
  },
  computed: {

  },
  watch: {
  },
  created: function () {
    this.getList();
  },
  methods: {
    getList: function () {
      this.listLoading = true;
      getarticle().then((res) => {
        this.cpu = res.data.cpu;
        this.dist = res.data.dist;
        // this.network = res.data.network;
        this.memory = res.data.memory;
        this.cpuData.rows = this.cpu.data;
        this.distData.rows = this.dist.data;
        // this.networkData.rows = this.network.data;
        this.memoryData.rows = this.memory.data;
        setTimeout(() => {
          this.listLoading = false;
        }, 0.1 * 2000);
      });
    },
    changePaging (pagingValues) {
      this.listQuery.length = pagingValues.length;
      this.listQuery.start = pagingValues.start;
      this.getList();
    }
  }
};
</script>

<style scoped>
  .runState {
    display: inline-block;
    width: 24%;
    text-align: center;
    position: relative;
  }
  .namePos{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -39%);
    font-size: 18px;
  }
  .stateTable{
    margin-top: 60px;
  }
  .refresh{
    color:#0f0 !important;
    font-weight:900;
    font-size: 16px;
    position: absolute;
    left: 20px;
    top: 0px;
    z-index: 4
  }
  .runStateMore{
    /*text-align: left;*/
    /*position:relative;*/
    /*width: 40%;*/
    /*left: 50%;*/
    /*transform: translate(-30%)*/
    text-align: center;
  }
  .state{
    position: relative;
    background: #f5f5f5;
    padding: 36px 0;
    /*top: 36px;*/
    height: 100%;
  }
  .state_row{
    min-height: 400px;
    background-color: #fcfcfc;
    padding-top: 10px;
  }
  .state_col_4{
    height: 100%;
    padding-top: 3%;
  }
  .state_title{
    position: absolute;
    top: 50%;
    left: 50%;
    font-size: 20px;
    transform: translate(-50%, -50%);
  }
  .process{
    padding-left: 18px;
    background: #f0f0f0;
    line-height: 2;
    margin-bottom: 0;
    font-weight: 400;
  }
</style>
