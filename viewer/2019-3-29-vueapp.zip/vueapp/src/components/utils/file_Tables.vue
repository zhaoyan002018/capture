<template>
  <div class="files">
    <div class="top_button">
      <el-button class=" danger outline" type="text" icon="el-icon-close" @click="Confirm()"> 删除</el-button>
      <el-button class="green outline" type="text" icon="el-icon-refresh" native-type="reset" @click="sort()" > 刷新 </el-button>
    </div>
    <el-table
      v-if="columns && columns.length"
      :id="id"
      :data="data"
      stripe
      border
      @sort-change="sortChange"
      @selection-change="selectRow"
      :class="tableClasses"
      tooltip-effect="dark"
      class="table-striped">
      <el-table-column type="selection" width="48px" align="center" />
      <el-table-column v-for="(column, index) in columns" :key="column.name" align="center" :prop="column.dataField" sortable>
        <template slot="header" slot-scope="scope">
          <el-tooltip :content="column.help" placement="top">
          <span>{{ column.name }}</span>
          </el-tooltip>
        </template>
        <template slot-scope="scope">
          <span v-if="index < 2">{{ scope.row[column.sort] }}</span>
          <!--name-->
          <span  v-else-if="index === 2">
            <a :href="'/download/'+ scope.row.fullname" v-if="scope.row['filesize'] >= 0">
              {{ scope.row.name }}
            </a>
            <span v-else>
              {{ scope.row.name }}
            </span>
          </span>
          <span v-else>
            <span v-if="column.dataFunction(scope.row[column.sort]) < 0" style="color: #f00">
              文件可能被删除
            </span>
            <span v-else>
             {{ column.dataFunction(scope.row[column.sort]) }}
            </span>
          </span>
        </template>
      </el-table-column>
      <el-table-column align="center" width="80">
        <template slot-scope="scope">
          <span @click="Confirm(scope.row)" >
             <svg-icon icon-class="del" />
          </span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import UserService from '../users/UserService';
import ToggleBtn from '../utils/ToggleBtn';
import { deleteAlert } from '@/api/validate';

/**
 * IMPORTANT! This component kicks off the loading of the
 * data in the table once the table state has been loaded.
 * There is no need to load data in the parent.
 */
export default {
  name: 'MolochFileTable',
  components: { ToggleBtn },
  props: {
    loadData: { // event to fire when the table needs to load data
      type: Function,
      required: true
    },
    id: { // unique id of the table
      type: String,
      required: false
    },
    tableClasses: { // table classes to be applied to the table
      type: String,
      require: false
    },
    /* IMPORTANT:
     * All columns must have a width.
     * Columns that should be shown by default (no table state saved) must have default flag */
    columns: { // columns to be displayed in the table
      type: Array,
      required: true
    },
    data: { // table data
      type: Array
    },
    tableStateName: { // api endpoint to save table state (/state/:tableStateName)
      type: String,
      required: true
    }
  },
  data: function () {
    return {
      error: '',
      tableDiv: undefined,
      tableDesc: undefined,
      tableSortField: undefined,
      sortModel: '',
      computedColumns: [], // columns in the order computed from the saved table state
      selectlistRow: []
    };
  },
  mounted: function () {
    this.tableDiv = `#${this.id}`;
    this.getTableState(); // IMPORTANT! this loads the data for the table
  },
  methods: {
    /* exposed page functions ------------------------------------ */
    sort: function (sort) {
      // 如果点击的是刷新按钮，效果时单纯刷新，不会调整顺序；
      if (sort === undefined) {
        this.loadData();
      } else {
        // if the sort field is the same, toggle it, otherwise set it to default (true)
        this.tableDesc = this.tableSortField === sort ? !this.tableDesc : true;
        this.tableSortField = sort;
        this.loadData(this.tableSortField, this.tableDesc);
      }
      this.saveTableState();
    },
    /* fits the table to the width of the current window size */
    /* helper functions ------------------------------------------ */
    getTableState: function () {
      UserService.getState(this.tableStateName)
        .then((response) => {
          if (response.data && response.data.order && response.data.visibleHeaders) {
            // there is a saved table state for this table
            // so apply it to sortField, desc, and column order
            this.tableSortField = response.data.order[0][0]; // num
            this.tableDesc = response.data.order[0][1] !== 'desc'; // true
          }
          this.loadData(this.tableSortField, this.tableDesc);
        })
        .catch(() => {
        });
    },
    saveTableState: function () {
      let tableState = {
        order: [[this.tableSortField, this.tableDesc === true ? 'desc' : 'asc']],
        visibleHeaders: []
      };
      for (let column of this.computedColumns) {
        tableState.visibleHeaders.push(column.id);
      }
      UserService.saveState(tableState, this.tableStateName);
    },
    cloneColumn: function (column) {
      let newCol = JSON.parse(JSON.stringify(column));
      if (column.dataFunction) {
        newCol.dataFunction = column.dataFunction;
      }
      if (column.avgTotFunction) {
        newCol.avgTotFunction = column.avgTotFunction;
      }
      return newCol;
    },
    sortChange: function (column, prop, order) {
      this.sortModel = column.prop;
      this.sort(column.prop);
    },
    deleteFile: function (row) {
      // console.log('out', row);
      let deleteRow = null;
      // 如果只删除一行，row的值是那一行；如果通过多选进行删除，row的值为undefined
      if (row) {
        // console.log('in', row);
        deleteRow = row;
      } else {
        // console.log('more', this.selectlistRow);
        deleteRow = this.selectlistRow;
      }
      this.axios.post('/deledtFildRow', {
        params: {
          row: {deleteRow}
        }
      }).then(res => {
        if (res.data.success) {
          this.$notify({
            title: res.data.message,
            type: 'success',
            duration: 2000
          });
        } else {
          this.$notify({
            title: res.data.message,
            type: 'error',
            duration: 2000
          });
        }
        this.loadData();
      });
    },
    selectRow (val) {
      this.selectlistRow = val;
    },
    Confirm (row) {
      let that = this;
      deleteAlert(that, this.deleteFile, row, '此操作将永久删除该文件，是否继续');
    }
  }
};
</script>

<style>
.top_button{
  border: 1px solid #f0f0f0;
  width: 158px;
  text-align: center;
  border-bottom: #fff;
  position: relative;
  z-index: 1;
  top: 1px;
  background: #fff;
  line-height: 32px;
  cursor: pointer;
}
/* force border radius on col vis menu btn */
.col-vis-menu > button.btn {
  border-top-right-radius: 4px !important;
  border-bottom-right-radius: 4px !important;;
}
.green{
  color:#0f0 !important;
  font-weight:900;
  border:1px solid transparent;
}
/* don't let col vis menu overflow the page */
.col-vis-menu .dropdown-menu {
  max-height: 300px;
  overflow: auto;
}
</style>

<style scoped>
/* table fit button -------------------------- */
/* make fit button pos relative to table */
table {
  position: relative;
}
button.fit-btn {
  position: absolute;
  right: 0;
  top: 0;
  visibility: hidden;
}
table > thead:hover button.fit-btn {
  visibility: visible;
}

/* column visibility menu styles ------------- */
.col-vis-menu .dropdown-header {
  padding: .25rem .5rem 0;
}

/* average/total delimeters ------------------ */
tr.bold {
  font-weight: bold;
}
table tr.border-bottom-bold > td {
  border-bottom: 2px solid #dee2e6;
}
table tr.border-top-bold > td {
  border-top: 2px solid #dee2e6;
}

/* table animation --------------------------- */
/*table .list-enter-active, .list-leave-active {*/
  /*transition: all .5s;*/
/*}*/
/*table .list-enter, .list-leave-to {*/
  /*opacity: 0;*/
  /*transform: translateX(30px);*/
/*}*/
/*table .list-move {*/
  /*transition: transform .5s;*/
/*}*/

/* slider grips indicator -------------------- */
table thead tr th {
  border-right: 1px dotted var(--color-gray);
}
/*table thead tr th.ignore-element {*/
  /*border-right: none;*/
/*}*/

/* remove terrible padding applied by the column resize lib */
.JPadding > tbody > tr > td, .JPadding > tbody > tr > th {
  padding: 0.75rem;
}
.table-sm.JPadding > tbody > tr > td, .table-sm.JPadding > tbody > tr > th {
  padding: 0.1rem 0.5rem !important;
}
</style>
