import Mock from 'mockjs';
import { param2Obj } from '@/api/index';

const List = [];
const count = 11;

const Info = {
  'buu.211360.com': 'TheOthers，异鬼是一种通过国内几大知名下载站的高速下载器传播的流氓推广程序，其隐藏在正规软件中，带有官方数字签名，并且通过改写VBR来隐藏、保护自身，最终实际的推广流氓模块均由云端下发，主要目的是篡改浏览器主页、劫持导航网站、后台刷流量等。',
  'iqp.sjime.com': 'TheOthers，异鬼是一种通过国内几大知名下载站的高速下载器传播的流氓推广程序，其隐藏在正规软件中，带有官方数字签名，并且通过改写VBR来隐藏、保护自身，最终实际的推广流氓模块均由云端下发，主要目的是篡改浏览器主页、劫持导航网站、后台刷流量等。'
};

for (let j = 0; j < count; j++) {
  List.push(Mock.mock({
    id: j + 1,
    commProtocol: '通信协议',
    'threatLevel|1': [ 1, 2, 3, 4, 5 ],
    'attackIp|1': ['0.0.0.0', '192.168.155.169', '1.1.2.6', '192.168.8.163'],
    'victIp|1': ['0.0.0.0', '192.168.155.169', '1.1.2.6', '192.168.8.163', '127.0.0.1'],
    findTime: '2019/1/7 00:00:00',
    threatLabel: '威胁情报',
    AssDomainName: ['buu.211360.com', 'iqp.sjime.com'],
    threatTimes: Math.ceil(Math.random() * 20),
    attIpLabel: 'TheOthers流氓推广活动事件',
    attLabelType: '流氓推广',
    victIpLabel: '内网服务器',
    state: 1,
    MAC: '70-77-81-C7-51-F5',
    detailIntr: {}
  }));
}

export default {
  getList: config => {
    // let VicHit = {}; // 威胁情报命中
    // 给每一行添加详细介绍
    for (let i in List) {
      for (let j in List[i].AssDomainName) {
        // if(VicHit[i]){

        // }
        List[i].detailIntr[List[i].AssDomainName[j]] = Info[List[i].AssDomainName[j]];
      }
    }

    let mockList = [];
    let item = [];
    let { length, start, filter, dashboard } = param2Obj(config.url);
    if (!dashboard) {
      if (filter) {
        // 将传过来的ip按';'切分成数组
        let filters = filter.split(';');
        for (let i = 0; i < filters.length; i++) {
          for (let j of List) {
            if (!(j.attackIp !== filters[i] && j.victIp !== filters[i])) {
              mockList.push(j);
            }
          }
        }
      } else {
        mockList = List;
      }
      for (let i = 0; i < length && start < mockList.length; i++) { // 取length个数据，从start开始取数据
        item.push(mockList[start]);
        start++;
      }
    } else {
      mockList = List;
      item = mockList;
    }
    return {
      total: mockList.length,
      items: item,
      recordsFiltered: mockList.length
    };
  },
  dispose: config => {
    let disposeData = JSON.parse(config.body);
    let item = {};
    for (let j in disposeData) {
      for (let i in List) {
        if (List[i].id === disposeData[j]) {
          List[i].state = 2;
          item = List[i];
        }
      }
    }
    return {
      text: '处理成功',
      items: item
    };
  }
};
