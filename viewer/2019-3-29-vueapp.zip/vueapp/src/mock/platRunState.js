import Mock from 'mockjs';

const cpu = {
  used: '2.5GHz',
  total: '26.4GHz',
  data: []
};
const Memory = {
  used: '3G',
  total: '26.4G',
  data: []
};
const dist = {
  used: '6G',
  total: '3T',
  data: []
};
const netWork = {
  data: []
};
const count = 25;

for (let j = 0; j < count; j++) {
  cpu.data.push(Mock.mock({
    'ratio': ['2.5', '2.6', '7', '6', '15'],
    time: j + 1
  }));
  Memory.data.push(Mock.mock({
    'ratio|1': ['2.5', '2.6', '7', '6', '15'],
    time: j + 1
  }));
  dist.data.push(Mock.mock({
    'read|1': ['2.5', '2.6', '7', '6', '15'],
    'write|1': ['2.5', '2.6', '7', '6', '15'],
    time: j + 1
  }));
}

export default {
  getList: config => {
    return {
      cpu: cpu,
      memory: Memory,
      dist: dist,
      network: netWork
    };
  }
};
