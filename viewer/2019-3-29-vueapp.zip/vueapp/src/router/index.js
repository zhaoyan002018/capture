import Vue from 'vue';
import Router from 'vue-router';
import store from '@/store';
import Stats from '@/components/stats/Stats';
// import Help from '@/components/help/Help';
import Files from '@/components/files/Files';
import Users from '@/components/users/Users';
import History from '@/components/history/History';
import Sessions from '@/components/sessions/Sessions';
import Spiview from '@/components/spiview/Spiview';
import Spigraph from '@/components/spigraph/Spigraph';
import Connections from '@/components/connections/Connections';
import Settings from '@/components/settings/Settings';
import Upload from '@/components/upload/Upload';
import Hunt from '@/components/hunt/Hunt';
import Dps404 from '@/components/utils/404';
import Layout from '@/components/layout/Layout';
import time from '@/components/time/time';
import routing from '@/components/routing/routing';
import linking from '@/components/linking/linking';
import interfaces from '@/components/interfaces/interfaces';
import Dashboard from '@/components/dashboard/index';
import EventMarage from '@/components/eventManage/index';
import WorldMap from '@/components/worldMap/index';
import China from '@/components/chinaMap/index';
// import report from '@/components/newReport/index';
import platRunState from '@/components/platformRunState/index';
import strategy from '@/components/strategy/index';
import userIp from '@/components/userIp/index';
import ruleBase from '@/components/ruleBase/index';
import exportReport from '@/components/exportReport/index';
Vue.use(Router);

/* eslint-disable no-undef */
const router = new Router({
  mode: 'history',
  base: DPS_PATH,
  scrollBehavior: function (to, from, savedPosition) {
    if (to.hash) {
      let yoffset = 150;

      if (to.path === '/help') {
        yoffset = 50;
      }

      return {
        selector: to.hash,
        offset: { x: 0, y: yoffset }
      };
    }
  },
  routes: [
    // {
    //   path: '/report',
    //   component: report,
    //   name: 'report',
    //   hidden: true
    // },
    {
      path: '/dashboard',
      component: Layout,
      name: 'dashboard',
      hidden: true,
      redirect: '/dashboard/index',
      children: [
        {
          path: 'index',
          component: Dashboard,
          name: 'index',
          meta: { title: '首页' }
        }
      ]
    },
    {
      path: '/sessions',
      component: Layout,
      redirect: '/sessions/index',
      children: [
        {
          path: 'index',
          component: Sessions,
          name: 'sessions',
          meta: {title: '会话', link: 'sessions'}
        }
      ]
    },
    {
      path: '/spiview',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Spiview,
          name: 'spiview',
          meta: {title: 'SPI视图', link: 'spiview'}
        }
      ]
    },
    {
      path: '/spigraph',
      component: Layout,
      alwaysShow: true,
      name: 'spigraph',
      meta: {title: 'SPI图表', link: 'spigraph'},
      permission: true,
      children: [
        {
          path: 'spigraphindex',
          component: Spigraph,
          name: 'spigraphindex',
          meta: {title: '图表', link: 'spigraph'},
          permission: true
        },
        {
          path: 'worldmap',
          component: WorldMap,
          name: 'worldmap',
          meta: {title: '世界地图', link: 'worldmap'},
          permission: true
        },
        {
          path: 'chinamap',
          component: China,
          name: 'chinamap',
          meta: {title: '国内地图', link: 'chinamap'},
          permission: true
        }
      ]
    },
    {
      path: '/connections',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Connections,
          name: 'connections',
          meta: {title: '连接', link: 'connections'}
        }
      ]
    },
    {
      path: '/files',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Files,
          name: 'files',
          meta: {title: '文件', link: 'files'},
          permission: 'hideFiles',
          reverse: true
        }
      ]
    },
    {
      path: '/stats',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Stats,
          name: 'stats',
          meta: {title: '状态', link: 'stats'},
          permission: 'hideStats',
          reverse: true
        }
      ]
    },
    {
      path: '/history',
      component: Layout,
      children: [
        {
          path: 'index',
          component: History,
          name: 'history',
          meta: {title: '操作记录', link: 'history'}
        }
      ]
    },
    {
      path: '/upload',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Upload,
          name: 'upload',
          meta: {title: '上传', link: 'upload'},
          permission: 'canUpload'
        }
      ]

    },
    {
      path: '/settings',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Settings,
          name: 'settings',
          meta: {title: '设置', link: 'settings'}
        }
      ]

    },
    {
      path: '/users',
      component: Layout,
      children: [
        {
          path: 'index',
          component: Users,
          name: 'users',
          meta: {title: '用户', link: 'users'}
        }
      ]
    },
    {
      path: '/network',
      alwaysShow: true,
      name: 'network',
      component: Layout,
      meta: { title: '网络配置', link: 'network' },
      permission: true,
      children: [
        {
          path: 'interfaces',
          name: 'interfaces',
          component: interfaces,
          meta: { title: '接口配置', link: 'interfaces' },
          permission: true
        },
        {
          path: 'routing',
          name: 'routing',
          component: routing,
          meta: { title: '路由配置', link: 'routing' },
          permission: true
        },
        {
          path: 'linking',
          name: 'linking',
          component: linking,
          meta: { title: '链路配置', link: 'linking' }
        }
      ]
    },
    {
      path: '/system',
      component: Layout,
      name: 'system',
      alwaysShow: true,
      meta: { title: '系统配置', link: 'system' },
      children: [
        {
          path: 'time',
          name: 'time',
          component: time,
          meta: { title: '时间配置', link: 'time' }
        },
        {
          path: 'platRunState',
          name: 'platRunState',
          component: platRunState,
          meta: { title: '平台运行状况', link: 'runState' }
        },
        {
          path: 'index',
          component: userIp,
          name: 'userIp',
          meta: {title: '用户绑定', link: 'userIp'}
        },
        {
          path: 'strategy',
          component: strategy,
          name: 'strategy',
          meta: {title: '策略配置', link: 'strategy'}
        },
        {
          path: 'ruleBase',
          component: ruleBase,
          name: 'ruleBase',
          meta: {title: '规则库', link: 'ruleBase'}
        }
      ]
    },
    {
      path: '/eventconfigure',
      component: Layout,
      name: 'eventconfigure',
      redirect: '/eventconfigure/eventmarage',
      alwaysShow: true,
      meta: { title: '事件配置', link: 'eventconfigure' },
      children: [
        {
          path: 'eventmarage',
          component: EventMarage,
          name: 'eventmarage',
          meta: { title: '攻击事件', link: 'eventmarage' }
        }
      ]
    },
    {
      path: '/exportReport',
      component: Layout,
      children: [
        {
          path: 'index',
          component: exportReport,
          name: 'exportReport',
          meta: { title: '报表导出', link: 'exportReport' }
        }
      ]
    },
    // {
    //   path: ''
    // },
    {
      path: '/help',
      name: 'help',
      component: Sessions,
      hidden: true
    },
    {
      path: '/hunt',
      name: 'Hunt',
      component: Hunt,
      meta: {title: 'hunt', link: 'hunt'},
      hidden: true
    },
    // {
    //   path: '/hunt',
    //   component: Layout,
    //   children: [
    //     {
    //       path: 'index',
    //       component: Hunt,
    //       name: 'hunt',
    //       meta: {title: 'hunt', link: 'hunt'}
    //     }
    //   ]
    // },
    {
      path: '*',
      name: 'Not Found',
      component: Dps404,
      hidden: true
    }
  ]
});

router.beforeEach((to, from, next) => {
  // always use the expression in the url query parameter if the navigation
  // was initiated from anything not in the moloch UI (browser forward/back btns)
  if (!to.params.nav && store.state.expression !== to.query.expression) {
    store.commit('setExpression', to.query.expression);
  }
  //  let page = to.name || ' dps - ';
  let view = to.query.view ? ` - ${to.query.view}` : '';
  let expression = to.query.expression ? ` - ${to.query.expression}` : '';

  /* eslint-disable no-undef */
  let title = DPS_TITLE_CONFIG
    .replace(/( *_-expression|_expression)_/g, expression)
    .replace(/( *_-view|_view)_/g, view);

  document.title = title;

  next();
});

export default router;
