<template>
  <div>
    <el-table :data="data"></el-table>
  </div>
</template>

<script>
export default {
  name: 'DpsTable',
  data () {
    data: []
  },
  props: {

  }
}
</script>

<style scoped>

</style>
