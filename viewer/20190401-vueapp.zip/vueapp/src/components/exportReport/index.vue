<template>
  <div>
    <div>
      <template>
        <div class="stage">
          <ul class="books-list">
            <li style="background: #F6F6F6;border: 1px solid #CCCCCC"
                @mouseenter="btnShow('fragility_btn')" @mouseleave="btnClose('fragility_btn')">
              <img src="@/assets/bgCover.png" alt="">
              <p style="position: absolute;z-index: 5;
                  top: 119px;
                  font-size: 17px;
                  left: 17px;">
                脆弱性感知报告</p>
              <div v-show="fragility_btn" style="position: absolute;z-index: 5;
              font-size:17px;bottom: 10px;width: 100%;">
                <span style="float: left;margin-left: 18px;cursor: pointer" @click="showDetail('fragility')">查看</span>
                <span style="float: right;margin-right: 15px;cursor: pointer" @click="exportReports()">导出</span>
              </div>
            </li>
            <li style="background: #CCCCCC"></li>
          </ul>
          <div class="desk"></div>
          <div class="desk-shadow"></div>
        </div>
        <!--<div>-->
          <!--<div style="position: relative;width: 150px;-->
                <!--height: 200px;top:30px; left: 30px;display: inline-block;z-index: 4;"-->
               <!--class="book">-->
            <!--<article style="position:absolute;width: 100%;height: 100%;background: #f0f0f0;z-index: 3;"-->
                     <!--class="cover">-->
            <!--<p style="text-align: center;line-height: 30px;">脆弱性感知报告</p>-->
            <!--</article>-->
            <!--<article style="position: absolute;width: 100%;height: 100%;background: #f00;z-index: 2">-->
              <!--<p style="text-align: center;line-height:30px;">目录</p>-->
            <!--</article>-->
          <!--</div>-->
        <!--</div>-->
      </template>
      <el-dialog :visible.sync="dialogFormVisible" title="导出PDF" width="400px" @close="resetTemp()">
        <div class="form">
          <el-form ref="dataForm" :model="temp" status-icon auto-complete="on" label-position="left" label-width="110px" style="margin-left:28px;" size="mini">
            <!--<el-form-item label="用户名">-->
              <!--<span>{{temp.name}}</span>-->
            <!--</el-form-item>-->
            <!--<el-form-item label="绑定IP">-->
              <!--<el-input v-model="temp.bundIp"></el-input>-->
            <!--</el-form-item>-->
            <el-form-item label="时间范围">
                <el-select v-model="temp.timeRange" placeholder="请选择">
                  <el-option v-for="item in timeRanges" :key="item.label" :label="item.label" :value="item.value"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="报表名称">
              <el-radio v-model="radio" label="1">默认</el-radio>
              <el-radio v-model="radio" label="2">自定义</el-radio>
              <div v-show="radio === '2'">
                <el-input v-model="temp.name"></el-input>
              </div>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button size="small" icon="el-icon-refresh" class="outline" type="info" @click="dialogFormVisible = false" >取消</el-button>
          <el-button size="small" icon="el-icon-circle-check-outline" class="outline" type="primary" @click="expReport()">确定</el-button>
        </div>
      </el-dialog>
      <!--loading overlay -->
    </div>
  </div>
</template>

<script>
// import { fetcharticle, updatearticle, deleteacticle, createArticle, editUpdatearticle } from '@/api/article';
// import { deleteAlert } from '@/api/validate';
// import MolochPaging from '@/components/utils/Pagination';

export default {
  data () {
    return {
      radio: '1',
      fragility_btn: false,
      temp: {},
      dialogFormVisible: false,
      timeRanges: [{
        value: 7,
        label: '最近一周'
      }, {
        value: 14,
        label: '最近两周'
      }, {
        value: 30,
        label: '最近一个月'
      }]
    };
  },
  created () {
  },
  methods: {
    showDetail (dom) {
      if (dom === 'fragility') {
        window.open('report/fragilityReport/fragilityReport.html');
      }
    },
    btnShow (dom) {
      this[dom] = true;
    },
    btnClose (dom) {
      this[dom] = false;
    },
    expReport () {
      this.dialogFormVisible = false;
    },
    exportReports () {
      this.dialogFormVisible = true;
    },
    resetTemp () {
      this.radio = '1';
      this.temp = {
      };
    }
  }
};
</script>
<style scoped>
  .action span{
    margin-left:20px;
  }
  ul{
    list-style:none;
  }
  .stage{
    position:relative;
    margin:100px;
  }
  .desk{
    background:#eae1dc;
    width:500px;
    height:20px;
    position:absolute;
    bottom:-35px;
    border-bottom:2px solid #f5ebe9;
    z-index:-1;
    -webkit-transform-style: preserve-3d;
    transform-style: preserve-3d;
  }

  .desk:after{
    content: "";
    background: #F2EDEA;
    width: 574px;
    position: absolute;
    height: 65px;
    -webkit-transform: perspective(300px) rotateX(50deg) translateX(-42px) translateY(-90px);
    transform: perspective(300px) rotateX(50deg) translateX(-42px) translateY(-90px);
  }
  .desk-shadow{
    position: absolute;
    bottom: -100px;
    z-index: -2;
    background: none;
    width: 510px;
    height: 65px;
    box-shadow: 0 56px 63px rgba(0,0,0,0.3);
    -webkit-transform: perspective(300px) rotateX(33deg) translateX(3px) translateY(-90px);
    transform: perspective(300px) rotateX(33deg) translateX(3px) translateY(-90px);
  }
  .books-list li{
    position:relative;
    display:inline-block;
    margin-left:12px;
    width:155px;
    height:215px;
    z-index:2;
    overflow-y:hidden;
    overflow-x:visible;
  }
  .books-list li img{
    width:100%;
    height: 100%;
  }
  .books-list li:after{
    content: "";
    position: absolute;
    overflow: hidden;
    right: 28px;
    bottom: 0px;
    width: 25px;
    height: 129px;
    background: rgba(0,0,0,0.4);
    box-shadow: 0 0 5px rgba(0,0,0,0.4);
    -webkit-transform: perspective(300px) rotateX(29deg) rotateY(-61deg) rotateZ(-11deg) translateX(8px) translateY(8px);
    transform: perspective(300px) rotateX(29deg) rotateY(-61deg) rotateZ(-11deg) translateX(8px) translateY(8px);
    z-index: -1;
  }
  .interfaceSet{
    width: 150px;
    height: 35px;
    line-height:35px;
    text-align: center;
    border:1px solid #f0f0f0;
    border-bottom:#fff;
    font-size:14px;
    position:relative;
    top:50px;
    z-index: 3;
    background: #ffffff;
  }
  .borders{
    position: relative;
    top: 49px;
    z-index: 2;
    border:1px solid #f0f0f0;
    padding-left:20px;
    width: 100%;
    border-bottom: transparent;
  }
  .links-table{
    position: relative;
    top: 49px;
  }
</style>
