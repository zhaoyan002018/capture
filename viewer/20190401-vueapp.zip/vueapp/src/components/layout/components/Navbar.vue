<template>

  <b-navbar
    fixed="top"
    toggleable="md"
    class="Navbar"
    type="dark">

    <!--logo-->
    <b-navbar-brand>
      <router-link :to="{ name: 'dashboard' }">
        <!--:to="{ path: helpLink.href, query: helpLink.query, params: { nav: true } }"-->
        <div id="helpTooltipContainer">
          <img src="../../../assets/logo.png"
          class="dps-logo"
            alt="hoot"
            id="tooltipHelp"
          />
        </div>
      </router-link>
      <b-tooltip :show="shiftKeyHold"
        triggers=""
        target="tooltipHelp"
        placement="leftbottom"
        container="helpTooltipContainer">
        <strong class="help-shortcut">H</strong>
      </b-tooltip>
    </b-navbar-brand>

    <!--toggle close-open-->
    <span style=" position: absolute;left: 145px;" @click="toggleOpen()" :class="{ toggleOpen: isopened}">
      <svg-icon icon-class="toggleOpen"></svg-icon>
    </span>
    <!--breadcrumb-->
    <breadcrumb class="breadcrumb-container"/>
    <el-tooltip content="screenfull" placement="bottom">
      <screenfull class="screenfull right-menu-item"/>
    </el-tooltip>
    <span @click="logout()">
      <el-tooltip content="logout" placement="bottom">
        <svg-icon icon-class="outs" class="logout" ></svg-icon>
      </el-tooltip>
    </span>
    <b-collapse is-nav
      id="nav_collapse">

      <b-navbar-nav
        class="ml-auto">
        <small class="navbar-text mr-2 text-right">
          {{ dpsVersion }}
        </small>
        <e-s-health></e-s-health>
      </b-navbar-nav>

    </b-collapse>
  </b-navbar>

</template>

<script>
// import qs from 'qs';
import Screenfull from '@/components/Screenfull';
import Breadcrumb from '@/components/Breadcrumb';
import ESHealth from '@/components/utils/ESHealth';

export default {
  name: 'MolochNavbar',
  components: { ESHealth, Screenfull, Breadcrumb },
  data: function () {
    return {
      dpsVersion: this.$constants.DPS_VERSION
    };
  },
  computed: {
    shiftKeyHold: function () {
      return this.$store.state.shiftKeyHold;
    },
    isopened: function () {
      return this.$store.state.isOpened;
    }
  },
  methods: {
    isActive: function (link) {
      return link === this.$route.path.split('/')[1];
    },
    logout: function () {
      this.$http.get('/logout').then(function () {
        window.location = '/logout';
      });
    },
    toggleOpen: function () {
      const MenuState = this.$store.state.menuState;
      if (MenuState) {
        this.$store.commit('setMenuState', false);
        this.$store.commit('setIsOpened', true);
      } else {
        this.$store.commit('setMenuState', true);
        this.$store.commit('setIsOpened', false);
      }
    }
  }
};
</script>

<style>
/* add an H tooltip by the owl but move it down a bit so
   that the links in the navbar are not covered up */
#helpTooltipContainer > div.tooltip {
  top: 16px !important;
}
/* move the arrow up to line up with the owl (since the
   tooltip was moved down) */
#helpTooltipContainer > div.tooltip > div.arrow {
  top: 2px !important;
}
/* make the tooltip smaller */
#helpTooltipContainer > div.tooltip > div.tooltip-inner {
  padding: 0 0.2rem !important;
}
</style>

<style scoped>
  .screenfull{
    position: absolute;
    right: 35px;
    top: 50%;
    margin-top: -12px;
  }
.Navbar  .logout{
    position:absolute;
    width:24px;
    height:24px;
    right:5px;
    top:50%;
    margin-top:-12px;
    cursor: pointer;
  }
nav.navbar {
  z-index: 6;
  max-height: 36px;
  min-height: 36px;
}
.dps-logo {
  position: absolute;
  height: 32px;
  top: 0px;
  left: 4px;
}
ul.navbar-nav {
  margin-left: 90px;
  margin-right:50px;
}
.breadcrumb-container {
  margin-left: 145px !important;
}
a.nav-link > a {
  text-decoration: none;
  color: rgba(255, 255, 255, 0.5);
}
a.nav-link:hover > a {
  color: rgba(255, 255, 255, 0.75);
}
a.nav-link > a.router-link-active {
  color: #fff;
}

/* apply theme colors to navbar */
.navbar-dark {
  background-color: var(--color-primary-dark);
  border-color: var(--color-primary-darker);
}

/* shortcut letter styles */
p { /* ::first-letter only works on blocks */
  margin-bottom: -16px;
  display: inline-block;
}
/* need this so that styled first letters don't expand the text */
p.shortcut-letter::first-letter {
  color: rgba(255, 255, 255, 0.5);
}
a.nav-link > a.router-link-active p.shortcut-letter::first-letter {
  color: #FFFFFF !important;
}
/* make sure hover still works */
.nav-link:hover p.shortcut-letter::first-letter {
  color: rgba(255, 255, 255, 0.75) !important;
}
/* style the sortcut letter */
p.shortcut-letter.holding-shift::first-letter {
  color: var(--color-tertiary-lighter) !important;
}
/* color the help shortcut letter in the tooltip */
.help-shortcut {
  color: var(--color-tertiary-lighter);
}
.toggleOpen{
  transform: rotateZ(90deg);
}
</style>
