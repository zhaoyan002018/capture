export { default as MolochNavbar } from './Navbar';
export { default as MolochSidebar } from './Sidebar/Sidebar.vue';
// export { default as TagsView } from './TagsView'
export { default as MolochBody } from './Body';
export { default as MolochFooter } from './Footer';
