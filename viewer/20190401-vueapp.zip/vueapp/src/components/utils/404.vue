<template>

  <div class="moloch-info container">

  <div class="center-area">

    <img src="watching.png" />

    <div class="well well-lg">
      <h1>404</h1>
      <h4>Nothing to see here...</h4>
    </div>

    <br/>

    <div class="margined-bottom">
      是不是想搜索
      <a href="sessions"
        class="no-decoration">
        sessions</a>?
    </div>

    <div>
      或者, 需要其他
      <a href="help"
        class="no-decoration">
        帮助</a>?
    </div>

  </div>

</div>

</template>

<script>
export default {
  name: 'Moloch404'
};
</script>
